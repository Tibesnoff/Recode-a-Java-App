import java.util.ArrayList;
import java.util.List;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Articles {
	private JSONArray json;
	private List<Article> articles;
	public Articles(JSONArray json) {
		this.json = json;
		articles = new ArrayList<Article>();
		for(Object j : json) {
        	articles.add(new Article((JSONObject) j));
        }
		//@SuppressWarnings("unchecked");
        //TODO convert to lambda

	}
	
	public List<Article> getArticles(){
		return articles;
	}
}
