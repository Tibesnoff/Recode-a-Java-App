import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Writer {
	private String firstName = null;
	private String lastName = null;
	private String title = null;
	private String role = null;
	
	public Writer(JSONArray jsonArray) {
		if(jsonArray.size() == 1) {
			JSONObject json = (JSONObject) jsonArray.get(0);
			this.firstName = json.get("firstname") != null?json.get("firstname").toString():null;
			this.lastName = json.get("lastname") != null?json.get("lastname").toString():null;
			this.title = json.get("title") != null?json.get("title").toString():null;
			this.role = json.get("role") != null?json.get("role").toString():null;
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
	public String toString() {
		return "First: " + firstName + " Last: " + lastName + "\n   Title:" + title + ", Role:" + role;
	}
	
	public boolean equals(String other) {
		String name = firstName + " " + lastName;
		return name.equals(other);
	}
}
