import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class ReadFile {
	private FileReader fileRead;
	private BufferedReader read;
	
	public ReadFile(String fileName) {
		try {
			fileRead = new FileReader(fileName);
			read = new BufferedReader(fileRead);
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			fileRead = null;
		} 
	}
	
	public ArrayList<String> getFileContents(){
		ArrayList<String> fileContents = new ArrayList<String>();
		
		if(fileRead == null)return null;
		read.lines().forEach(l -> fileContents.add(l.toString()));
		return fileContents;
	}
}
