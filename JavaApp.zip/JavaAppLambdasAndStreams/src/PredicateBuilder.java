import java.util.function.Predicate;
import java.lang.invoke.SerializedLambda;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
public class PredicateBuilder {
	private Class<? extends PredicateBuilder> c;
	
	public PredicateBuilder() {
		c = this.getClass();
	}
	
	@SuppressWarnings("unchecked")
	public Predicate<Article> generalPredicate(String field, String value) {
		Method m;
		Predicate<Article> builtPredicate = null;
		try {
			m = c.getDeclaredMethod((field + "Predicate"), String.class);
			builtPredicate = (Predicate<Article>) m.invoke(this, value);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		
		return builtPredicate;
	}
	
	public Predicate<Article> writerPredicate(String writer){
		return (i -> i.getWriter().equals(writer.toString()));
	}
	
	public Predicate<Article> datePredicate(String date){
		return (i -> i.getPublishedDate().equals(new Date(date)));
	}
	
	public Predicate<Article> titlePredicate(String title){
		return (i -> i.getTitle().equals(title));
	}
	
	public Predicate<Article> urlPredicate(String url){
		return (i -> i.getUrl().equals(url));
	}
	
	public Predicate<Article> sectionPredicate(String section){
		return (i -> i.getSection().equals(section));
	}
	
}
