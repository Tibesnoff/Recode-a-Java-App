import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
public class Articles {
	private JSONArray json;
	private List<Article> articles;
	public Articles(JSONArray json) {
		this.json = json;
		articles = new ArrayList<Article>();
		json.stream().forEach(a -> articles.add(new Article((JSONObject)a)));
	}
	
	public List<Article> getArticles(){
		return articles;
	}
}
