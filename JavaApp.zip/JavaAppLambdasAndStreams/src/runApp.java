import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class runApp {
	FetchAPI fetch;
	Articles articles;
	Filter filter;
	PrintFilters printer;
	ReadFile fileReader;
	PredicateBuilder pBuilder;
	
	public runApp() {
		System.out.println("Running.......");
		fetch = new FetchAPI();
		articles = fetch.Fetch();
		filter = new Filter(articles);
		printer = new PrintFilters(filter);
		run();
	}
	
	public void run() {	
		if(articles == null) {
			System.out.println("No articles found");
			return;
		}
				
		pBuilder = new PredicateBuilder();
		fileReader = new ReadFile("filtersForBoss.txt");
		fileReader.getFileContents().stream().forEach(l -> {
			if(l.equalsIgnoreCase("all"))articles.getArticles().stream().forEach(a -> System.out.println(a));
			else {
				String field = l.substring(0,l.indexOf(':'));
				String value = l.substring(l.indexOf(':') + 1, l.length());
				Predicate<Article> predicate = (Predicate<Article>)pBuilder.generalPredicate(field, value);
				printer.print(predicate, ("field: " + field + "\n  value: " + value));
			}
		});
	}
}
