import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
public class Filter {
	private List<Article> articles;
	
	public Filter(Articles articles) {
		this.articles = articles.getArticles();
	};
	//TODO combine all into one filter method using predicate
	
	public List<Article> filterByPublishedDate(Date date){
		List<Article> filteredArticles = new ArrayList<Article>();
		//TODO convert to lambda
		for(Article a:articles) {
			if(a.getPublishedDate().equals(date))filteredArticles.add(a);
		}		
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public List<Article> filterByWriter(String writer){
		List<Article> filteredArticles = new ArrayList<Article>();
		//TODO convert to lambda
		for(Article a:articles) {
			if(a.getWriter().equals(writer))filteredArticles.add(a);
		}	
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public void noneFound(List<Article> articles) {
		if(articles.size() == 0)System.out.println("No articles found with that filter");
	}
}
