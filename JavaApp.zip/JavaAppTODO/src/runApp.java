import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class runApp {
	FetchAPI fetch;
	Articles articles;
	Filter filter;
	PrintFilters printer;
	ReadFile fileReader;
	PredicateBuilder pBuilder;
	
	public runApp() {
		System.out.println("Running.......");
		fetch = new FetchAPI();
		articles = fetch.Fetch();
		filter = new Filter(articles);
		printer = new PrintFilters(filter);
		run();
	}
	
	public void run() {	
		if(articles == null) {
			System.out.println("No articles found");
			return;
		}
		
		printer.PrintWriterFilter("Livia Albeck-Ripka");
		printer.PrintPublishedFilter(new Date("2023-01-31"));
		
		/*TODO Read in the file, use the file contents array as a stream to find articles,
		 *if any, that match the given line
		 *Needed:
		 *Check if the line is all then print all articles
		 *Call to printer.print
		 *Creation of a predicate using the PredicateBuilder class
		 */
	}
}
