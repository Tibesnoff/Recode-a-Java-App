import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class ReadFile {
	/*private FileReader fileRead;
	private BufferedReader read;*/
	private File file;
	private Scanner scan;
	
	public ReadFile(String fileName) {
		try {
			
			file = new File(fileName);
			scan = new Scanner(file);
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			
			file = null;
		} 
	}
	
	public ArrayList<String> getFileContents(){
		ArrayList<String> fileContents = new ArrayList<String>();
		
		/*Original TODO turn into stream use BufferedReader and FileReader hint try 
		 *.lines() instead of .stream() it is the same thing except .lines() is for 
		 *buffered reader
		 */
		if(file == null)return null;
		
		while(scan.hasNextLine())fileContents.add(scan.nextLine());
		
		return fileContents;
	}
}
