import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class ReadFile {
	/*private FileReader fileRead;
	private BufferedReader read;*/
	private File file;
	private Scanner scan;
	
	public ReadFile(String fileName) {
		try {
			/*fileRead = new FileReader(fileName);
			read = new BufferedReader(fileRead);*/
			
			file = new File(fileName);
			scan = new Scanner(file);
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
			//fileRead = null;
			
			file = null;
		} 
	}
	
	public ArrayList<String> getFileContents(){
		ArrayList<String> fileContents = new ArrayList<String>();
		
		//Original TODO turn into stream use BufferedReader and FileReader
		if(file == null)return null;
		
		while(scan.hasNextLine())fileContents.add(scan.nextLine());
		
		/*if(fileRead == null)return null;
		read.lines().forEach(l -> fileContents.add(l.toString()));
		return fileContents;*/
		
		return fileContents;
	}
}
