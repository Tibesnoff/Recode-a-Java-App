import java.util.List;
import java.util.function.Predicate;

public class PrintFilters {
	Filter filter;

	public PrintFilters(Filter filter) {
		this.filter = filter;
	}
	
	//TODO Combine all into one print predicate
	public void print(Predicate<Article> p, String filterVals) {
		System.out.println("List of all articles matching your filter: \n " + filterVals + "\n");
		filter.filter(a -> p.test(a)).stream().forEach(a -> System.out.println(a.toString()));
	}
	
	public void PrintPublishedFilter(Date date) {
		System.out.println("List of articles published on " + date + "\n");
		//filter.filter(a -> a.getPublishedDate().equals(date)).stream().forEach(a -> System.out.println(a.toString()));

		List<Article> filteredDateArticles = filter.filterByPublishedDate(date);
		
		//TODO Convert to lambda
		for(Article a:filteredDateArticles)System.out.println(a.toString());		
		
		//filter.filterByPublishedDate(createDateFilter).stream().forEach(a -> System.out.println(a.toString()));
	}
	
	public void PrintWriterFilter(String writer) {
		System.out.println("List of articles with the writer: " + writer);
		
		//filter.filter(a -> a.getByline().substring(3).equals(writer)).stream().forEach(a -> System.out.println(a.toString()));

		List<Article> filteredWriterArticles = filter.filterByWriter(writer);
		
		//TODO Convert to lambda
		for(Article a:filteredWriterArticles)System.out.println(a.toString());
		
		//filter.filterByWriter(writerFilter).stream().forEach(a -> System.out.println(a.toString()));
	}
}	


	