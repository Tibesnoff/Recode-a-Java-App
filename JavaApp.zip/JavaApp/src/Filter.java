import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Filter {
	List<Article> articles;
	
	public Filter(Articles articles) {
		this.articles = articles.getArticles();
	};
	//TODO combine all into one filter method using predicate
	
	/*public List<Article> filter(Predicate<Article> p){
 		List<Article> filteredArticles = new ArrayList<Article>();
 		filteredArticles = (List<Article>) articles.stream().filter(a -> p.test(a)).collect(Collectors.toList());
	 	noneFound(filteredArticles);
	 	return filteredArticles; 
	}*/
	
	public List<Article> filterByPublishedDate(Date date){
		List<Article> filteredArticles = new ArrayList<Article>();
		//TODO convert to lambda
		for(Article a:articles) {
			if(a.getPublishedDate().equals(date)) {
				filteredArticles.add(a);
			}
		}		
		//filteredArticles = (List<Article>) articles.stream().filter(a -> a.getPublishedDate().equals(date)).collect(Collectors.toList());
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public List<Article> filterByWriter(String writer){
		List<Article> filteredArticles = new ArrayList<Article>();
		//TODO convert to lambda
		for(Article a:articles) {
			if(a.getWriter().equals(writer)) {
				filteredArticles.add(a);
			}
		}	
		//filteredArticles = (List<Article>) articles.stream().filter(a -> a.getByline().substring(3).equals(writer)).collect(Collectors.toList());
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public void noneFound(List<Article> articles) {
		if(articles.size() == 0) {
			System.out.println("No articles found with that filter");
		}
	}
}
