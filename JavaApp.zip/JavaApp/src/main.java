import java.util.List;

public class main {
	public static void main(String[] args) {
		FetchAPI fetch = new FetchAPI();
		Articles articles = fetch.Fetch();
		Filter filter = new Filter(articles);
		PrintFilters printer = new PrintFilters(filter);
		Date publishedDateFilter = new Date("2023-01-31"); //Change date to current day
		String writerFilter = "Livia Albeck-Ripka";

		
		if(articles == null) {
			System.out.println("No articles found");
			return;
		}
		
		//TODO Convert to lambda
		System.out.println("List of first 10 articles\n");
		for(Article a:articles.getArticles().subList(0, 10)) {
			System.out.println(a.toString());
		}
		//articles.getArticles().subList(0, 10).forEach(a -> System.out.println(a.toString()));

		printer.PrintPublishedFilter(publishedDateFilter);
		
		//TODO get the article that was published by Livia Albeck-Ripka on 1-31-2023
		//printer.print(a -> a.getWriter().equals(writerFilter) && a.getPublishedDate().equals(publishedDateFilter), "written by " + writerFilter + " on " + publishedDateFilter);
		
	
	}
}
