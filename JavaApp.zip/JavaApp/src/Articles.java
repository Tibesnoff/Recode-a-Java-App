import java.util.ArrayList;
import java.util.List;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class Articles {
	private JSONArray json;
	private List<Article> articles;
	public Articles(JSONArray json) {
		this.json = json;
		articles = new ArrayList<Article>();
        //TODO convert to lambda
		for(Object j : json) {
        	articles.add(new Article((JSONObject) j));
        }
		//@SuppressWarnings("unchecked");
		//List<Article> articles = (List<Article>) articlesArray.stream().map(a -> new Article((JSONObject) a)).collect(Collectors.toList());
	}
	
	public List<Article> getArticles(){
		return articles;
	}
}
