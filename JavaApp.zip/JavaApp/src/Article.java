import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class Article {
	private String section;
    private String title;
    private String url;
    private Writer writer;
    private Date publishedDate;
    
    public Article(JSONObject json) {
        this.title = (String) ((JSONObject)json.get("headline")).get("main");
        this.url = (String) json.get("web_url");
        JSONArray writerArray = (JSONArray)((JSONObject)json.get("byline")).get("person");
        this.writer = new Writer(writerArray);
        this.section = (String) json.get("section");
        this.publishedDate = new Date(((String) json.get("pub_date")).substring(0,10));
    }
    
	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Writer getWriter() {
		return writer;
	}

	public void setWriter(Writer writer) {
		this.writer = writer;
	}

	public Date getPublishedDate() {
		return publishedDate;
	}

	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}

	@Override
	public String toString() {
		return "Article [title: " + title + "\n writer:\n   " + writer + "\n section:" + section + "\n url:" + url + "\n publishedDate:" + publishedDate + "]\n";
	}
    
    
}
