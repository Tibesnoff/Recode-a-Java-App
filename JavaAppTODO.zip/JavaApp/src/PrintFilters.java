import java.util.List;
import java.util.function.Predicate;

public class PrintFilters {
	Filter filter;

	public PrintFilters(Filter filter) {
		this.filter = filter;
	}
	
	//TODO Combine all into one print predicate
	
	
	public void PrintPublishedFilter(Date date) {
		System.out.println("List of first 10 articles published on " + date + "\n");

		List<Article> filteredDateArticles = filter.filterByPublishedDate(date);
		
		//TODO Convert to lambda
		for(Article a:filteredDateArticles.subList(0, 10)) {
			System.out.println(a.toString());
		}
		
	}
	
	public void PrintWriterFilter(String writer) {
		System.out.println("List of first 10 articles with the writer: " + writer);
		

		List<Article> filteredWriterArticles = filter.filterByWriter(writer);
		
		//TODO Convert to lambda
		for(Article a:filteredWriterArticles.subList(0, 10)) {
			System.out.println(a.toString());
		}
		
	}
}	


	