import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class FetchAPI {
    private String apikey = "4sK101J2F7LiKryX8GnCpA8xl5MXbhYh";
    private String month = "1";
    private String year = "2023";
	private String apiUrl = "https://api.nytimes.com/svc/archive/v1/" + year + "/" + month + ".json?api-key=" + apikey;

    public Articles Fetch() {
	    try {
	    	URL url = new URL(apiUrl);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setRequestMethod("GET");
	        connection.setRequestProperty("apikey", apikey);
	        connection.setRequestProperty("Accept-Charset", "UTF-8");
	        
	        if(connection.getResponseCode() != 200) {
	        	System.out.println("Could not connect to the API");
	        }
	        
	        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
	        StringBuilder response = new StringBuilder();
	        	        
	        String line;
	        
	        //TODO convert to lambda use .lines() as BufferedReader .stream() is called .lines() Hint: response can be turned into a string instead of strin builder or you can use line
	        while ((line = reader.readLine()) != null) {
	            response.append(line);
	        }
	        
	        reader.close();
	        
	        JSONParser parser = new JSONParser();
	        JSONObject json = (JSONObject) parser.parse(response.toString());
	        json = (JSONObject) parser.parse(json.get("response").toString());
	        JSONArray articlesArray = (JSONArray)parser.parse(json.get("docs").toString());
	        
	        return new Articles(articlesArray);
	    } catch (IOException | ParseException e) {
	        e.printStackTrace();
	    }
	    return null;
    }
    
}
