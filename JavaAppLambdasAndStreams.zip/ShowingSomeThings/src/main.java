
public class main {

	public static void main(String[] args) {
		show s = new show();
		
		//Lambda block expressions
		//s.part1();
		
		System.out.println("");
		
		//Chaining predicates
		//s.part2();
		
		System.out.println("");

		//Interesting package I found
		s.part3();
		
	}

}
