import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.function.Predicate;

public class show {
	ArrayList<Integer> ints;
	
	public show() {
		ints = new ArrayList<Integer>();
		for(int i = 0; i<10; i++)ints.add(i + 1);
		
	}
	
	//Lambda block expressions
	public void part1() {
		for(int i:ints) {
			System.out.println("Square " + square(i) + " Cube "  + cube(i));
		}
		
		ints.stream().forEach(i -> {
			int square = i * i;
			int cube = i * i * i;
			System.out.println("Square " + square + " Cube "  + cube);
		});
		
		ints.stream().forEach((i) -> System.out.println("Square " + square(i) +
													    " Cube "  + cube(i)));
		
		ints.stream().forEach(i -> printVal(i));
	}
	
	public void printVal(int i) {
		System.out.println("Square " + square(i) + " Cube "  + cube(i));
	}
	
	public int square(int i) {
		return i * i;
	}
	
	public int cube(int i) {
		return i * i * i;
	}
	
	//chaining predicates
	public void part2() {
		for(int i:ints) {
			if((i % 2 == 0) && (i == 1 || i == 2 || i == 3 || i == 5 || i == 7)) {
				System.out.println(i);
			}
		}
		
		Predicate<Integer> is_even = (i) -> (i % 2 == 0);
		Predicate<Integer> is_prime = (i) -> (i == 1 || i == 2 || i == 3 || i == 5 || i == 7);
		ints.stream().filter(is_even.and(is_prime)).forEach((i) -> System.out.println());
	}
	
	//Interesting package I found
	public void part3() {
		List<Integer> primes = Arrays.asList(2, 3, 5, 7, 11, 13, 17, 19, 23, 29);
		IntSummaryStatistics stats = primes.stream().mapToInt((x) -> x).summaryStatistics(); 
		System.out.println(stats);
		System.out.println("Highest prime number in List : " + stats.getMax()); 
		System.out.println("Lowest prime number in List : " + stats.getMin()); 
		System.out.println("Sum of all prime numbers : " + stats.getSum()); 
		System.out.println("Average of all prime numbers : " + stats.getAverage());

	}
}
