import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class Writer {
	private String firstName = null;
	private String lastName = null;
	
	public Writer(JSONArray jsonArray) {
		if(jsonArray.size() == 1) {
			JSONObject json = (JSONObject) jsonArray.get(0);
			this.firstName = json.get("firstname") != null?json.get("firstname").toString():null;
			this.lastName = json.get("lastname") != null?json.get("lastname").toString():null;
		}
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Override
	public String toString() {
		return "First: " + firstName + " Last: " + lastName;
	}
	
	public boolean equals(String other) {
		String name = firstName + " " + lastName;
		return name.equals(other);
	}
}
