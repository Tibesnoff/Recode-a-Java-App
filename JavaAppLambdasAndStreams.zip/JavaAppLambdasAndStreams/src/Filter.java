import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
public class Filter {
	private List<Article> articles;
	
	public Filter(Articles articles) {
		this.articles = articles.getArticles();
	};
	
	public List<Article> filter(Predicate<Article> p){
 		List<Article> filteredArticles = new ArrayList<Article>();
 		filteredArticles = (List<Article>) articles.stream().filter(a -> p.test(a)).collect(Collectors.toList());
	 	noneFound(filteredArticles);
	 	return filteredArticles; 
	}
	
	public List<Article> filterByPublishedDate(Date date){
		List<Article> filteredArticles = new ArrayList<Article>();
		filteredArticles = (List<Article>) articles.stream().filter(a -> a.getPublishedDate().equals(date)).collect(Collectors.toList());
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public List<Article> filterByWriter(String writer){
		List<Article> filteredArticles = new ArrayList<Article>();	
		filteredArticles = (List<Article>) articles.stream().filter(a -> a.getWriter().equals(writer)).collect(Collectors.toList());
		noneFound(filteredArticles);
		return filteredArticles;
	}
	
	public void noneFound(List<Article> articles) {
		if(articles.size() == 0)System.out.println("No articles found with that filter");
	}
}
